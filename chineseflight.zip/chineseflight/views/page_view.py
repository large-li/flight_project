# -*- coding:utf-8 -*-
from flask import Blueprint, render_template

"""
本视图专门用于处理页面
"""
page = Blueprint('page', __name__)


@page.route('/', endpoint="home")
def login():
    return render_template("home.html")


@page.route('/hot_cities', endpoint="hot_cities")
def hot_cities():
    return render_template("hot_cities.html")


@page.route('/funnel', endpoint="funnel")
def funnel():
    return render_template("funnel.html")


@page.route('/airline_company', endpoint="airline_company")
def airline_company():
    return render_template("airline_company.html")


@page.route('/pro_company', endpoint="pro_company")
def pro_company():
    return render_template("pro_company.html")


@page.route('/to_and_from', endpoint="to_and_from")
def to_and_from():
    return render_template("to_and_from.html")


@page.route('/to_city', endpoint="to_city")
def to_city():
    return render_template("to_city.html")
